import{l as o,b as r}from"../chunks/cLnldb3O.js";export{o as load_css,r as start};
